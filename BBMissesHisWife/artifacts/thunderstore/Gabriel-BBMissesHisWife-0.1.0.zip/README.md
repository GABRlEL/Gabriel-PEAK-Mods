# I miss my wife / BBMissesHisWife

Literally just makes Bing Bong say "I miss my wife" in PEAK all the time.
